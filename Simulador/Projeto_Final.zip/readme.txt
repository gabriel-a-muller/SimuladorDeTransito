Simulador de trânsito.
Por Gabriel Alexandre Müller.

O programa implementado nesta pasta simula um trânsito de veículos com dois cruzamentos.
O usuário apenas deve iniciá-lo, sem qualquer tipo de pré-configuração.

Os carros são representados por quadrados pretos.
Para rodar o programa abra o projeto no QTCreator.

Lista de arquivos:

Sources:
	cruzamento.cpp
	gerador.cpp
	main.cpp
	mainwindow.cpp
	rua.cpp
	trafego.cpp

Headers:
	Cruzamento.h
	ExcecaoInvalida.h
	gerador.h
	imagemcarro.h
	mainwindow.h
	Rua.h
	Trafego.h
	Veiculo.h


